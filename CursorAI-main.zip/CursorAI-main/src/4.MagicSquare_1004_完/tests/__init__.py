"""MagicSquare test package."""
